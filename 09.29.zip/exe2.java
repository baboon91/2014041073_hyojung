
public class exe2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] coinUnit = {500, 100, 50, 10};
		int money = 2680;
		int tem=0;
		int a = 0;
		int b = 0;
		int c = 0;
		int d = 0;
		System.out.println("money="+money);
		for(int i=0;i<coinUnit.length;i++) {
		a = money/500;
		tem =money%500;
		b = tem/100;
		tem = tem%100;
		c = tem / 50;
		tem = tem%50;
		d = tem/10;	
	}
		System.out.println("500�� =" + a);
		System.out.println("100�� =" + b);
		System.out.println("50�� =" + c);
		System.out.println("10�� =" + d);
	}

}
